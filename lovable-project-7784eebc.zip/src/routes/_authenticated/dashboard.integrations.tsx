import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { TrendingUp, Bell, Key, Webhook, ChevronRight } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/dashboard/integrations")({
  component: IntegrationsPage,
});

const INTEGRATIONS = [
  { id: "utmify", group: "TRACKING", name: "UTMify", desc: "Rastreie conversões e atribuição UTM das suas vendas no painel UTMify.", icon: TrendingUp, color: "bg-violet-50 text-violet-600", status: "available" },
  { id: "pushcut", group: "NOTIFICAÇÕES", name: "Pushcut", desc: "Receba notificações push no iPhone sempre que fizer uma venda com sucesso.", icon: Bell, color: "bg-sky-50 text-sky-600", status: "available" },
  { id: "apikeys", group: "DEVELOPER", name: "API Keys", desc: "Gere as suas chaves de API para integração programática com a sua aplicação.", icon: Key, color: "bg-amber-50 text-amber-600", status: "available" },
  { id: "webhooks", group: "DEVELOPER", name: "Webhooks", desc: "Receba notificações em tempo real de eventos da sua conta.", icon: Webhook, color: "bg-emerald-50 text-emerald-600", status: "available" },
];

function IntegrationsPage() {
  const [selected, setSelected] = useState<string | null>(null);
  const groups = Array.from(new Set(INTEGRATIONS.map(i => i.group)));

  if (selected) return <IntegrationDetail id={selected} onBack={() => setSelected(null)} />;

  return (
    <div className="space-y-4">
      <div className="px-1">
        <h1 className="text-2xl font-semibold tracking-tight">Integrações</h1>
        <p className="text-sm text-muted-foreground">Conecte ferramentas externas para automatizar e rastrear as suas vendas</p>
      </div>

      {groups.map(g => (
        <div key={g} className="space-y-2">
          <p className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground px-1">{g}</p>
          {INTEGRATIONS.filter(i => i.group === g).map(it => (
            <Card key={it.id} className="rounded-2xl shadow-sm p-5">
              <div className="flex items-start justify-between">
                <div className={`h-11 w-11 rounded-xl flex items-center justify-center ${it.color}`}><it.icon className="h-5 w-5" /></div>
                <span className="text-xs px-2 py-1 rounded-md bg-sky-50 text-sky-700">Disponível</span>
              </div>
              <h3 className="mt-3 font-semibold">{it.name}</h3>
              <p className="text-sm text-muted-foreground">{it.desc}</p>
              <button onClick={() => setSelected(it.id)} className="mt-3 text-sm text-sky-600 flex items-center gap-1 font-medium">
                Configurar <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </Card>
          ))}
        </div>
      ))}
    </div>
  );
}

function IntegrationDetail({ id, onBack }: { id: string; onBack: () => void }) {
  const it = INTEGRATIONS.find(i => i.id === id)!;
  const [apiKey, setApiKey] = useState("");
  const [webhook, setWebhook] = useState("");

  return (
    <div className="space-y-4">
      <button onClick={onBack} className="text-sm text-muted-foreground">← Voltar para integrações</button>
      <div className="flex items-start gap-3">
        <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${it.color}`}><it.icon className="h-6 w-6" /></div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-semibold">{it.name}</h1>
            <span className="text-xs px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700">● Configurado</span>
          </div>
          <p className="text-sm text-muted-foreground max-w-md">{it.desc}</p>
        </div>
      </div>

      <Card className="rounded-2xl shadow-sm p-5">
        <h3 className="text-xs uppercase tracking-wider text-muted-foreground mb-3">Como funciona</h3>
        <ol className="space-y-3 text-sm">
          {["Crie uma conta e obtenha a sua API key", "Insira a API key e o webhook URL abaixo", "Quando um pagamento for confirmado, enviaremos os dados automaticamente"].map((s,i)=>(
            <li key={i} className="flex items-start gap-3">
              <span className="h-5 w-5 rounded-full bg-violet-100 text-violet-700 text-xs flex items-center justify-center font-semibold shrink-0">{i+1}</span>
              <span>{s}</span>
            </li>
          ))}
        </ol>
      </Card>

      <Card className="rounded-2xl shadow-sm p-5 space-y-4">
        <h3 className="text-xs uppercase tracking-wider text-muted-foreground">Configuração</h3>
        <div className="space-y-2">
          <Label>API KEY</Label>
          <Input value={apiKey} onChange={(e)=>setApiKey(e.target.value)} placeholder="••••••••••••••••" className="font-mono" />
        </div>
        <div className="space-y-2">
          <Label>WEBHOOK URL</Label>
          <Input value={webhook} onChange={(e)=>setWebhook(e.target.value)} placeholder="https://..." />
        </div>
        <div className="flex justify-between pt-2">
          <Button variant="ghost" onClick={()=>{setApiKey("");setWebhook("");}}>Limpar</Button>
          <Button className="bg-foreground text-background" onClick={()=>toast.success("Configuração guardada!")}>Guardar configuração</Button>
        </div>
      </Card>
    </div>
  );
}
