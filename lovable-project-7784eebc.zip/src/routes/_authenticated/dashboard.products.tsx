import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { listMyProducts, createProduct, toggleProduct, deleteProduct } from "@/lib/products.functions";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Copy, Plus, Trash2, ExternalLink, Search, Package as PackageIcon, Upload, Loader2, X } from "lucide-react";
import { toast } from "sonner";
import { useMemo, useRef, useState } from "react";

export const Route = createFileRoute("/_authenticated/dashboard/products")({
  component: ProductsPage,
});

const fmtMT = (n: number) => `${new Intl.NumberFormat("pt-MZ", { maximumFractionDigits: 0 }).format(n)} MT`;

function ProductsPage() {
  const qc = useQueryClient();
  const fetchList = useServerFn(listMyProducts);
  const create = useServerFn(createProduct);
  const toggle = useServerFn(toggleProduct);
  const del = useServerFn(deleteProduct);

  const { data: products = [] } = useQuery({ queryKey: ["products"], queryFn: () => fetchList() });
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState<"all" | "active" | "inactive">("all");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", description: "", price_mzn: "", cover_path: "", cover_preview: "", delivery_url: "" });
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const filtered = useMemo(() => products.filter(p => {
    if (tab === "active" && !p.active) return false;
    if (tab === "inactive" && p.active) return false;
    if (query && !p.name.toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  }), [products, query, tab]);

  const createM = useMutation({
    mutationFn: () => create({ data: { name: form.name, description: form.description, price_mzn: Number(form.price_mzn), cover_path: form.cover_path, delivery_url: form.delivery_url } }),
    onSuccess: (p) => {
      toast.success(`Produto criado! Link: /c/${p.slug}`);
      setForm({ name: "", description: "", price_mzn: "", cover_path: "", cover_preview: "", delivery_url: "" });
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["products"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Erro"),
  });

  async function handleFile(file: File) {
    if (!file.type.startsWith("image/")) { toast.error("Selecione uma imagem"); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error("Máx 5MB"); return; }
    setUploading(true);
    try {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Sessão expirada");
      const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
      const path = `${u.user.id}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
      const { error } = await supabase.storage.from("product-images").upload(path, file, { upsert: false });
      if (error) throw error;
      const { data: signed } = await supabase.storage.from("product-images").createSignedUrl(path, 3600);
      setForm((f) => ({ ...f, cover_path: path, cover_preview: signed?.signedUrl || "" }));
      toast.success("Imagem carregada");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Falha no upload");
    } finally { setUploading(false); }
  }

  function copyLink(slug: string) {
    navigator.clipboard.writeText(`${window.location.origin}/c/${slug}`);
    toast.success("Link copiado!");
  }

  return (
    <div className="space-y-4">
      <div className="px-1">
        <h1 className="text-2xl font-semibold tracking-tight">Produtos</h1>
        <p className="text-sm text-muted-foreground">{products.length} produtos</p>
      </div>

      <Button onClick={() => setOpen(!open)} className="w-full h-12 rounded-xl bg-foreground text-background hover:bg-foreground/90">
        <Plus className="h-4 w-4" /> Novo produto
      </Button>

      <Card className="rounded-2xl shadow-sm p-4 space-y-3">
        <div className="relative">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Pesquisar produto..." className="pl-9 bg-secondary border-0 h-11 rounded-xl" />
        </div>
        <div className="flex gap-2">
          {(["all","active","inactive"] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-4 h-8 rounded-lg text-sm font-medium transition-colors ${tab===t ? "bg-foreground text-background" : "text-muted-foreground"}`}>
              {t === "all" ? "Todos" : t === "active" ? "Ativos" : "Inativos"}
            </button>
          ))}
        </div>
      </Card>

      {open && (
        <Card className="rounded-2xl shadow-sm p-5 space-y-4">
          <div className="space-y-2"><Label>Nome *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div className="space-y-2"><Label>Preço (MZN) *</Label><Input type="number" value={form.price_mzn} onChange={(e) => setForm({ ...form, price_mzn: e.target.value })} /></div>
          <div className="space-y-2"><Label>Descrição</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
          <div className="space-y-2">
            <Label>Imagem de capa</Label>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); e.target.value = ""; }} />
            {form.cover_preview ? (
              <div className="relative">
                <img src={form.cover_preview} alt="Capa" className="w-full h-40 object-cover rounded-xl" />
                <button type="button" onClick={() => setForm((f) => ({ ...f, cover_path: "", cover_preview: "" }))} className="absolute top-2 right-2 h-8 w-8 rounded-full bg-background/90 flex items-center justify-center shadow"><X className="h-4 w-4" /></button>
              </div>
            ) : (
              <button type="button" onClick={() => fileRef.current?.click()} disabled={uploading}
                className="w-full h-32 rounded-xl border-2 border-dashed border-border flex flex-col items-center justify-center gap-2 text-sm text-muted-foreground hover:bg-secondary/50 transition-colors">
                {uploading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Upload className="h-5 w-5" />}
                {uploading ? "Carregando..." : "Carregar da galeria"}
              </button>
            )}
          </div>
          <div className="space-y-2"><Label>Link de entrega</Label><Input value={form.delivery_url} onChange={(e) => setForm({ ...form, delivery_url: e.target.value })} placeholder="https://..." /></div>
          <div className="flex gap-2">
            <Button onClick={() => createM.mutate()} disabled={!form.name || !form.price_mzn || createM.isPending || uploading} className="bg-foreground text-background">
              {createM.isPending && <Loader2 className="h-4 w-4 animate-spin" />} Criar produto
            </Button>
            <Button variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-2 gap-3">
        {!filtered.length && (
          <div className="col-span-2 text-center text-sm text-muted-foreground py-10">Sem produtos.</div>
        )}
        {filtered.map((p) => (
          <Card key={p.id} className="rounded-2xl shadow-sm overflow-hidden p-3">
            <div className="aspect-square rounded-xl bg-secondary overflow-hidden relative">
              {p.cover_url ? <img src={p.cover_url} alt={p.name} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-muted-foreground"><PackageIcon className="h-10 w-10" /></div>}
              <span className={`absolute top-2 left-2 inline-flex items-center gap-1 text-[11px] px-2 py-1 rounded-md ${p.active ? "bg-emerald-50 text-emerald-700" : "bg-secondary text-muted-foreground"}`}>
                <span className={`h-1.5 w-1.5 rounded-full ${p.active ? "bg-emerald-500" : "bg-muted-foreground"}`} /> {p.active ? "Ativo" : "Inativo"}
              </span>
            </div>
            <div className="pt-3 px-1">
              <p className="font-medium text-sm truncate">{p.name}</p>
              <p className="font-semibold mt-0.5">{fmtMT(Number(p.price_mzn))}</p>
              <div className="flex items-center gap-1 mt-2">
                <button onClick={() => copyLink(p.slug)} className="flex-1 h-8 rounded-lg bg-secondary text-foreground/80 flex items-center justify-center gap-1 text-xs"><Copy className="h-3 w-3" />Link</button>
                <a href={`/c/${p.slug}`} target="_blank" rel="noreferrer" className="h-8 w-8 rounded-lg bg-secondary flex items-center justify-center"><ExternalLink className="h-3 w-3" /></a>
                <button onClick={() => toggle({ data: { id: p.id, active: !p.active } }).then(() => qc.invalidateQueries({ queryKey: ["products"] }))} className="h-8 px-2 rounded-lg bg-secondary text-xs">{p.active ? "Off" : "On"}</button>
                <button onClick={() => { if (confirm("Eliminar?")) del({ data: { id: p.id } }).then(() => qc.invalidateQueries({ queryKey: ["products"] })); }} className="h-8 w-8 rounded-lg bg-secondary flex items-center justify-center text-[#e11d48]"><Trash2 className="h-3 w-3" /></button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
